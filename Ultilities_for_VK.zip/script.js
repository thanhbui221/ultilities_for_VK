document.onmouseup = function(){
  console.log('yup');
};
